Kegiatan komputerisasi adalah sebuah kegiatan 
pengelolaan data dalam rangka menghasilkan 
informasi-informasi penting bagi manajemen, agar 
yang bersangkutan mampu mengendalikan 
perusahaan yang menjadi tanggungjawabnya dengan 
lebih baik. 