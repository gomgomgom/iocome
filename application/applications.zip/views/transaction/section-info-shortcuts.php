<h4>Shortcuts</h4>
<small><code>Shift + I</code> : Choosing type Income</small>
<small><code>Shift + O</code> : Choosing type Outcome</small>
<small><code>Shift + A</code> : Add to Record data temporary</small>
<small><code>Shift + R</code> : Clear all Record data temporary</small>
<small><code>Shift + S</code> : Save income / outcome</small>