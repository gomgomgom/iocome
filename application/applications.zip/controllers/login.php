<?php
class Login extends CI_Controller
{
	function __construct()
	{
		parent::__construct();
	}
	
	function index()
	{
		$this->load->view('login');
	}
	
	// We can't encrypt password on client side, this is article to explain the reason ::
	// Source :: http://stackoverflow.com/questions/4121629/password-encryption-at-client-side
	// Source :: http://stackoverflow.com/questions/3715920/about-password-hashing-system-on-client-side
	function process_login()
	{
		// Get data (POST method)
		$parameter = file_get_contents("php://input");
		
		// print_r($parameter);exit;
		
		// Decode data
		$decode_param = json_decode($parameter);
		
		// Validation format parameter
		if(! isset($decode_param->Username) ||
			! isset($decode_param->Password)
		){
			echo json_encode(array('Status' => 500, 'Message' => 'Your format parameter is wrong')); // 500 = Internal Server Error
			exit;
		}
		
		// Validation of null value
		if($decode_param->Username == '' ||
			$decode_param->Password == ''
		){
			echo json_encode(array('Status' => 500, 'Message' => 'Your format parameter must be filled')); // 500 = Internal Server Error
			exit;
		}
		
		// Set variable
		$username = $decode_param->Username;
		$password = $decode_param->Password;
		
		// Check to database
		$result = $this->db->get_where('tbl_user', array('username'=>$username, 'password'=>md5($password)));
		if($result->num_rows() > 0){
			// Set last login
			// In order to create same value between last login at database and session
			$last_login_time = date('Y-m-d H:i:s', strtotime("now"));
			
			// Insert data last login
			$this->db->where('id', $result->row()->id);
			$this->db->update('tbl_user', array('last_login_time'=>$last_login_time));
			
			// Save session
			$data = array(
				'username' => $username,
				'name' => $result->row()->name,
				'last_login' => $last_login_time
			);
			$this->session->set_userdata($data);
			
			// Return login success
			// 200 = OK
			echo json_encode(array('Status' => 200, 'Message' => 'Login Success'));
			
		} else {
		
			// Return login failed
			// 500 = Internal Server Error
			echo json_encode(array('Status' => 500, 'Message' => 'Login Failed'));
		}
		
		
	}
	
}
?>