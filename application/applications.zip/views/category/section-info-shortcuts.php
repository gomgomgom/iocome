<h4>Shortcuts</h4>
<small><code>Shift + N</code> : Add new category</small>
<small><code>Shift + M</code> : Add new child category</small>
<small><code>Shift + S</code> : Save category</small>